import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Sphere, Torus } from '@react-three/drei';
import gameState from './gameState';

export default function Objective() {
  const coreRef = useRef();
  const extractRef = useRef();

  useFrame((state) => {
    const time = state.clock.elapsedTime;
    
    // Toggle visibility without React state/re-renders
    if (coreRef.current) {
      coreRef.current.visible = !gameState.coreCollected;
      if (!gameState.coreCollected) {
        coreRef.current.position.y = 0.6 + Math.sin(time * 3) * 0.2;
        coreRef.current.rotation.y = time;
      }
    }
    
    if (extractRef.current) {
      extractRef.current.visible = gameState.coreCollected && !gameState.victory;
      if (extractRef.current.visible) {
        extractRef.current.rotation.z = time * 0.5;
        const scale = 1 + Math.sin(time * 4) * 0.05;
        extractRef.current.scale.set(scale, scale, scale);
      }
    }
  });

  return (
    <group>
      <Sphere ref={coreRef} args={[0.3, 16, 16]} position={[16, 0.6, 16]} castShadow>
        <meshStandardMaterial color="#3be2ff" emissive="#3be2ff" emissiveIntensity={2} toneMapped={false} />
        <pointLight color="#3be2ff" intensity={2} distance={6} />
      </Sphere>
      
      <Torus ref={extractRef} args={[0.8, 0.1, 16, 32]} position={[-16, 0.1, -16]} rotation={[Math.PI / 2, 0, 0]}>
        <meshStandardMaterial color="#3bff6e" emissive="#3bff6e" emissiveIntensity={2} toneMapped={false} />
        <pointLight color="#3bff6e" intensity={2} distance={6} />
      </Torus>
    </group>
  );
}
