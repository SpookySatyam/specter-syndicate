import React, { useState, useEffect, useCallback } from 'react';
import gameState from './gameState';

// ---------------------------------------------------------------------------
// Styles — dark/moody to match the game aesthetic
// ---------------------------------------------------------------------------
const S = {
  overlay: {
    position: 'absolute',
    inset: 0,
    pointerEvents: 'none',
    fontFamily: '"JetBrains Mono", "Fira Code", "Courier New", monospace',
    zIndex: 10,
    userSelect: 'none',
  },
  scanlines: {
    position: 'absolute',
    inset: 0,
    pointerEvents: 'none',
    background: 'linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.25) 50%), linear-gradient(90deg, rgba(255, 0, 0, 0.06), rgba(0, 255, 0, 0.02), rgba(0, 0, 255, 0.06))',
    backgroundSize: '100% 4px, 3px 100%',
    boxShadow: 'inset 0 0 100px rgba(0,0,0,0.9)',
    zIndex: 5,
  },
  vignette: (isLowHealth) => ({
    position: 'absolute',
    inset: 0,
    pointerEvents: 'none',
    boxShadow: isLowHealth ? 'inset 0 0 150px rgba(255,0,0,0.5)' : 'none',
    transition: 'box-shadow 0.2s',
    animation: isLowHealth ? 'vignettePulse 1s alternate infinite' : 'none',
    zIndex: 4,
  }),

  // ── Top-Left: Health Only ──
  topLeft: {
    position: 'absolute',
    top: 24,
    left: 24,
    display: 'flex',
    flexDirection: 'column',
    gap: 4,
  },
  healthOuter: {
    width: 220,
    height: 14,
    background: 'rgba(0,0,0,0.6)',
    borderRadius: 3,
    border: '1px solid rgba(255,255,255,0.08)',
    overflow: 'hidden',
  },
  healthInner: (pct, color, justHealed) => ({
    width: `${pct}%`,
    height: '100%',
    background: justHealed ? '#00ff44' : color,
    boxShadow: justHealed ? '0 0 15px #00ff44' : 'none',
    transition: 'width 0.15s ease-out, background 0.3s, box-shadow 0.3s',
    animation: pct < 25 ? 'healthPulse 1.5s infinite alternate' : 'none',
    borderRadius: 3,
  }),
  healthLabel: {
    fontSize: 10,
    letterSpacing: 1.5,
    color: 'rgba(255,255,255,0.75)',
    textTransform: 'uppercase',
    marginBottom: 2,
  },

  // ── Top-Center: Objective + Level ──
  topCenter: {
    position: 'absolute',
    top: 20,
    left: '50%',
    transform: 'translateX(-50%)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  objectiveText: (highlight) => ({
    fontSize: 13,
    letterSpacing: 2,
    color: highlight ? '#3be2ff' : '#3bff6e',
    textTransform: 'uppercase',
    textShadow: highlight ? '0 0 8px rgba(59,226,255,0.4)' : '0 0 8px rgba(59,255,110,0.4)',
    fontWeight: 'bold',
  }),

  // ── Top-Right: Alert Bar ──
  topRight: {
    position: 'absolute',
    top: 24,
    right: 24,
  },
  alertBar: {
    background: 'rgba(150, 0, 0, 0.4)',
    border: '1px solid rgba(255, 59, 59, 0.6)',
    borderRadius: 4,
    padding: '6px 14px',
    display: 'flex',
    alignItems: 'center',
    color: '#ff3b3b',
    fontWeight: 800,
    fontSize: 13,
    letterSpacing: 2,
    textTransform: 'uppercase',
    textShadow: '0 0 10px rgba(255,59,59,0.7)',
    animation: 'alertPulse 0.6s infinite alternate',
    boxShadow: '0 0 15px rgba(255, 0, 0, 0.3)',
  },

  // ── Bottom-Left: Mode & Stats ──
  bottomLeft: {
    position: 'absolute',
    bottom: 24,
    left: 24,
    display: 'flex',
    flexDirection: 'column',
    gap: 12,
  },
  modeRow: {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
  },
  modeSwatch: (color) => ({
    width: 12,
    height: 12,
    borderRadius: 2,
    background: color,
    boxShadow: `0 0 6px ${color}66`,
  }),
  modeText: {
    fontSize: 12,
    letterSpacing: 1.2,
    color: 'rgba(255,255,255,0.9)',
    textTransform: 'uppercase',
    fontWeight: 'bold',
  },
  statsText: {
    fontSize: 10,
    letterSpacing: 1.5,
    color: 'rgba(255,255,255,0.6)',
    textTransform: 'uppercase',
  },

  // ── Bottom-Center: Controls ──
  bottomCenter: {
    position: 'absolute',
    bottom: 24,
    left: '50%',
    transform: 'translateX(-50%)',
    pointerEvents: 'auto',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  controlsPanel: (isExpanded) => ({
    background: 'rgba(0,0,0,0.85)',
    border: '1px solid rgba(255,255,255,0.15)',
    borderRadius: isExpanded ? 4 : 24,
    padding: isExpanded ? '14px 18px' : '0',
    width: isExpanded ? 'auto' : 32,
    height: isExpanded ? 'auto' : 32,
    display: 'flex',
    flexDirection: 'column',
    alignItems: isExpanded ? 'flex-start' : 'center',
    justifyContent: isExpanded ? 'flex-start' : 'center',
    gap: 6,
    transition: 'all 0.4s ease',
    overflow: 'hidden',
    cursor: isExpanded ? 'default' : 'pointer',
    opacity: isExpanded ? 1 : 0.6,
  }),
  controlsIcon: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'rgba(255,255,255,0.8)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    height: '100%',
  },
  controlsHeading: {
    fontSize: 13,
    letterSpacing: 1.5,
    color: 'rgba(255,255,255,0.95)',
    textTransform: 'uppercase',
    marginBottom: 4,
    whiteSpace: 'nowrap',
  },
  controlsLine: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.85)',
    textTransform: 'uppercase',
    display: 'flex',
    alignItems: 'center',
    gap: 2,
    whiteSpace: 'nowrap',
  },
  kbd: {
    fontFamily: '"JetBrains Mono", "Fira Code", "Courier New", monospace',
    background: 'rgba(255,255,255,0.1)',
    borderRadius: 2,
    padding: '1px 4px',
    marginRight: 2,
    marginLeft: 2,
    display: 'inline-block',
  },
  controlsWarning: {
    fontSize: 9,
    color: 'rgba(255,80,80,0.75)',
    textTransform: 'uppercase',
    marginTop: 4,
    whiteSpace: 'nowrap',
  },

  // ── Game-over overlay ──
  gameOver: {
    position: 'absolute',
    inset: 0,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    background: 'rgba(0,0,0,0.82)',
    pointerEvents: 'auto',
  },
  caughtText: {
    fontSize: 52,
    fontWeight: 800,
    letterSpacing: 14,
    color: '#ff3b3b',
    textShadow: '0 0 30px rgba(255,59,59,0.5)',
    textTransform: 'uppercase',
    marginBottom: 12,
  },
  subtitle: {
    fontSize: 13,
    letterSpacing: 3,
    color: 'rgba(255,255,255,0.35)',
    textTransform: 'uppercase',
    marginBottom: 36,
  },
  restartBtn: {
    padding: '12px 36px',
    fontSize: 13,
    fontWeight: 700,
    fontFamily: 'inherit',
    letterSpacing: 3,
    textTransform: 'uppercase',
    color: '#fff',
    background: 'rgba(255,59,59,0.15)',
    border: '1px solid rgba(255,59,59,0.4)',
    borderRadius: 4,
    cursor: 'pointer',
    transition: 'background 0.2s, border-color 0.2s',
    pointerEvents: 'auto',
  },

  // ── Victory Styles ──
  victoryText: {
    fontSize: 52,
    fontWeight: 800,
    letterSpacing: 14,
    color: '#3bff6e',
    textShadow: '0 0 30px rgba(59,255,110,0.5)',
    textTransform: 'uppercase',
    marginBottom: 12,
    textAlign: 'center',
  },
  restartBtnVictory: {
    padding: '12px 36px',
    fontSize: 13,
    fontWeight: 700,
    fontFamily: 'inherit',
    letterSpacing: 3,
    textTransform: 'uppercase',
    color: '#fff',
    background: 'rgba(59,255,110,0.15)',
    border: '1px solid rgba(59,255,110,0.4)',
    borderRadius: 4,
    cursor: 'pointer',
    transition: 'background 0.2s, border-color 0.2s',
    pointerEvents: 'auto',
  },
  
  // ── Level Complete Transition ──
  levelCompleteText: {
    fontSize: 42,
    fontWeight: 800,
    letterSpacing: 10,
    color: '#3be2ff',
    textShadow: '0 0 30px rgba(59,226,255,0.5)',
    textTransform: 'uppercase',
    marginBottom: 12,
  },
};

// ---------------------------------------------------------------------------
// Health bar color: green → yellow → red
// ---------------------------------------------------------------------------
function healthColor(pct) {
  if (pct > 60) return '#3bff6e';
  if (pct > 30) return '#ffd93b';
  return '#ff3b3b';
}

// ---------------------------------------------------------------------------
// HUD component — rendered as DOM overlay OUTSIDE <Canvas>
// ---------------------------------------------------------------------------
const keyframes = `
@keyframes healthPulse {
  0% { opacity: 1; box-shadow: 0 0 12px rgba(255, 59, 59, 0.8); }
  100% { opacity: 0.5; box-shadow: 0 0 2px rgba(255, 59, 59, 0.2); }
}
@keyframes vignettePulse {
  0% { box-shadow: inset 0 0 200px rgba(255, 0, 0, 0.6); }
  100% { box-shadow: inset 0 0 80px rgba(255, 0, 0, 0.2); }
}
@keyframes alertPulse {
  0% { opacity: 1; box-shadow: 0 0 20px rgba(255, 0, 0, 0.5); }
  100% { opacity: 0.6; box-shadow: 0 0 5px rgba(255, 0, 0, 0.1); }
}
`;

export default function HUD({ onRestart }) {
  // Force-update counter — incremented by gameState.notify()
  const [, setTick] = useState(0);
  const [justHealed, setJustHealed] = useState(false);
  const [controlsCollapsed, setControlsCollapsed] = useState(false);
  const [controlsHovered, setControlsHovered] = useState(false);

  useEffect(() => {
    let healTimeout;
    const unsub = gameState.subscribe(() => {
      setTick((n) => n + 1);
      
      if (gameState.healPulse > 0 && Date.now() - gameState.healPulse < 100) {
        setJustHealed(true);
        clearTimeout(healTimeout);
        healTimeout = setTimeout(() => setJustHealed(false), 300);
      }
    });
    return () => {
      unsub();
      clearTimeout(healTimeout);
    };
  }, []);

  // Collapse controls after 6 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setControlsCollapsed(true);
    }, 6000);
    return () => clearTimeout(timer);
  }, []);

  // Read live values from the singleton (already throttled by Player.jsx)
  const hp = Math.round(Math.max(0, gameState.health));
  const pct = (hp / gameState.maxHealth) * 100;
  const detected = gameState.detected;
  const isGameOver = gameState.gameOver;
  const isVictory = gameState.victory;
  const isLevelComplete = gameState.levelComplete;
  const hideHint = isGameOver || isVictory || isLevelComplete;
  const isLowHealth = hp > 0 && hp < 25;
  const mins = Math.floor(gameState.syncedSurvivalTime / 60);
  const secs = (gameState.syncedSurvivalTime % 60).toString().padStart(2, '0');

  const handleRestart = useCallback(() => {
    if (onRestart) onRestart();
  }, [onRestart]);

  const showFullControls = !controlsCollapsed || controlsHovered;
  const isHighlightObjective = !gameState.coreCollected;
  const objectiveString = !gameState.coreCollected ? 'Recover the Core' : 'Reach Extraction';

  return (
    <div style={S.overlay}>
      <style>{keyframes}</style>
      <div style={S.scanlines} />
      <div style={S.vignette(isLowHealth)} />
      
      {/* ── Top-Left: Health ── */}
      <div style={S.topLeft}>
        <div style={S.healthLabel}>Hull Integrity</div>
        <div style={S.healthOuter}>
          <div style={S.healthInner(pct, healthColor(pct), justHealed)} />
        </div>
      </div>

      {/* ── Top-Center: Objective + Level ── */}
      <div style={S.topCenter}>
        <div style={S.objectiveText(isHighlightObjective)}>
          LEVEL {gameState.level} &middot; {objectiveString}
        </div>
      </div>

      {/* ── Top-Right: Alert Bar ── */}
      {detected && !hideHint && (
        <div style={S.topRight}>
          <div style={S.alertBar}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{marginRight: 8}}>
              <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
              <line x1="12" y1="9" x2="12" y2="13"></line>
              <line x1="12" y1="17" x2="12.01" y2="17"></line>
            </svg>
            DETECTED
          </div>
        </div>
      )}

      {/* ── Bottom-Left: Mode & Stats ── */}
      <div style={S.bottomLeft}>
        <div style={S.modeRow}>
          <div style={S.modeSwatch(gameState.modeColor)} />
          <span style={S.modeText}>{gameState.modeName} Mode</span>
        </div>
        <div style={S.statsText}>
          SURVIVED: {mins}:{secs} &middot; THREATS: {gameState.hunterCount}
        </div>
      </div>

      {/* ── Bottom-Center: Controls ── */}
      {!hideHint && (
        <div 
          style={S.bottomCenter}
          onMouseEnter={() => setControlsHovered(true)}
          onMouseLeave={() => setControlsHovered(false)}
        >
          <div style={S.controlsPanel(showFullControls)}>
            {showFullControls ? (
              <>
                <div style={S.controlsHeading}>Controls</div>
                <div style={S.controlsLine}>
                  <span style={S.kbd}>WASD</span> / <span style={S.kbd}>Arrows</span> — Move
                </div>
                <div style={S.controlsLine}>
                  <span style={S.kbd}>Space</span> — Jump (vault pillars)
                </div>
                <div style={S.controlsLine}>
                  <span style={S.kbd}>1</span> — Aggro (Red)
                </div>
                <div style={S.controlsLine}>
                  <span style={S.kbd}>2</span> — Tank (Blue)
                </div>
                <div style={S.controlsLine}>
                  <span style={S.kbd}>3</span> — Stealth (Purple)
                </div>
                <div style={S.controlsWarning}>Avoid spotlights — land on hunters to stomp them</div>
              </>
            ) : (
              <div style={S.controlsIcon}>?</div>
            )}
          </div>
        </div>
      )}

      {/* ── Game-over screen ── */}
      {isGameOver && (
        <div style={S.gameOver}>
          <div style={S.caughtText}>Caught</div>
          <div style={S.subtitle}>The shadows could not hide you</div>
          <button
            style={S.restartBtn}
            onClick={handleRestart}
            onMouseEnter={(e) => {
              e.target.style.background = 'rgba(255,59,59,0.3)';
              e.target.style.borderColor = 'rgba(255,59,59,0.7)';
            }}
            onMouseLeave={(e) => {
              e.target.style.background = 'rgba(255,59,59,0.15)';
              e.target.style.borderColor = 'rgba(255,59,59,0.4)';
            }}
          >
            Try Again
          </button>
        </div>
      )}

      {/* ── Victory screen ── */}
      {isVictory && (
        <div style={S.gameOver}>
          <div style={S.victoryText}>ALL THREATS<br/>NEUTRALIZED</div>
          <div style={S.subtitle}>You made it out alive</div>
          <button
            style={S.restartBtnVictory}
            onClick={handleRestart}
            onMouseEnter={(e) => {
              e.target.style.background = 'rgba(59,255,110,0.3)';
              e.target.style.borderColor = 'rgba(59,255,110,0.7)';
            }}
            onMouseLeave={(e) => {
              e.target.style.background = 'rgba(59,255,110,0.15)';
              e.target.style.borderColor = 'rgba(59,255,110,0.4)';
            }}
          >
            Play Again
          </button>
        </div>
      )}

      {/* ── Level Complete screen ── */}
      {isLevelComplete && !isVictory && (
        <div style={S.gameOver}>
          <div style={S.levelCompleteText}>LEVEL {gameState.level} COMPLETE</div>
          <div style={S.subtitle}>Proceeding deeper...</div>
        </div>
      )}
    </div>
  );
}
