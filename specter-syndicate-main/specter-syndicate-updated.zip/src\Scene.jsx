/**
 * Scene configuration for Specter Syndicate.
 *
 * CAMERA SETTINGS:
 * - Isometric angle is achieved by placing an OrthographicCamera at roughly [15, 15, 15].
 * - The camera looks down at the origin [0, 0, 0].
 * - Adjust the `zoom` prop (currently 50) to change the framing of the play area.
 * - Higher zoom = closer to the character, lower zoom = wider view.
 */

import React, { useState } from 'react';
import { useFrame } from '@react-three/fiber';
import CameraRig from './CameraRig';
// import { OrbitControls } from '@react-three/drei';
import Environment from './Environment';
import Player from './Player';
import Hunter from './Hunter';
import Objective from './Objective';
import HealthPack from './HealthPack';
import gameState from './gameState';

// Patrol routes — spread across the play area so the player must weave between them
import { HEALTH_PACK_POSITIONS } from './levelGeometry';

const PATROL_ROUTES = [
  [[-6, -6], [6, -6], [6, 6], [-6, 6]],          // center square (0)
  [[-12, -10], [-4, -10], [-4, -2], [-12, -2]],  // south-west block (1)
  [[3, 8], [12, 3], [10, 12]],                   // north-east triangle (2)
  [[-12, 10], [-4, 10], [-4, 2], [-12, 2]],      // North-West (3)
  [[4, -12], [12, -12], [12, -4], [4, -4]],      // South-East (4)
  [[0, -12], [14, 0], [0, 12], [-14, 0]],        // Diamond (5)
  [[-8, -8], [8, 8]],                            // Diagonal line (6)
  [[8, -8], [-8, 8]],                            // Diagonal line 2 (7)
  [[-10, 0], [-10, -8], [0, -8]],                // L-shape (8)
  [[10, 0], [10, 8], [0, 8]],                    // L-shape 2 (9)
];

const LEVEL_CONFIG = {
  1: {
    startCount: 3,
    speedMult: 1.0,
    schedule: [
      { time: 0, count: 3 },
      { time: 30, count: 4 },
      { time: 60, count: 5 },
      { time: 90, count: 6 },
      { time: 120, count: 7 }
    ]
  },
  2: {
    startCount: 4,
    speedMult: 1.15,
    schedule: [
      { time: 0, count: 4 },
      { time: 30, count: 5 },
      { time: 60, count: 6 },
      { time: 90, count: 7 },
      { time: 120, count: 8 },
      { time: 150, count: 9 }
    ]
  },
  3: {
    startCount: 5,
    speedMult: 1.3,
    schedule: [
      { time: 0, count: 5 },
      { time: 30, count: 6 },
      { time: 60, count: 7 },
      { time: 90, count: 8 },
      { time: 120, count: 9 },
      { time: 150, count: 10 }
    ]
  }
};

function HunterManager() {
  const [activeCount, setActiveCount] = useState(() => (LEVEL_CONFIG[gameState.level] || LEVEL_CONFIG[1]).startCount);
  
  useFrame((_, delta) => {
    if (gameState.gameOver || gameState.victory) return;
    
    gameState.survivalTime += delta;
    
    const config = LEVEL_CONFIG[gameState.level] || LEVEL_CONFIG[1];
    let targetCount = config.startCount;
    for (let i = 0; i < config.schedule.length; i++) {
      if (gameState.survivalTime >= config.schedule[i].time) {
        targetCount = config.schedule[i].count;
      }
    }
    
    // Cap at available routes
    targetCount = Math.min(targetCount, PATROL_ROUTES.length);

    if (targetCount !== activeCount) {
      setActiveCount(targetCount);
      gameState.hunterCount = targetCount;
    }
  });

  const speedMult = (LEVEL_CONFIG[gameState.level] || LEVEL_CONFIG[1]).speedMult;

  return (
    <>
      {Array.from({ length: activeCount }).map((_, i) => (
        <Hunter key={`hunter-${i}`} id={`hunter-${i}`} patrolPoints={PATROL_ROUTES[i]} speedMult={speedMult} />
      ))}
    </>
  );
}

export default function Scene() {
  return (
    <>
      {/* Background & Atmosphere */}
      <color attach="background" args={['#0d0d14']} />
      <fog attach="fog" args={['#0d0d14', 45, 110]} />

      {/* Camera */}
      <CameraRig />
      {/* <OrbitControls /> */} {/* Uncomment for debug purposes */}

      {/* Lighting */}
      <ambientLight intensity={1.2} />
      <hemisphereLight args={['#5a7aab', '#1a1a2f', 0.8]} />

      <directionalLight
        castShadow
        position={[10, 20, 5]}
        intensity={2.5}
        color="#c8d1e0"
        shadow-mapSize={[2048, 2048]}
      >
        <orthographicCamera
          attach="shadow-camera"
          args={[-20, 20, 20, -20, 0.5, 50]}
        />
      </directionalLight>

      {/* World */}
      <Environment />

      {/* Entities */}

      <Objective />
      {HEALTH_PACK_POSITIONS.map((pos, i) => (
        <HealthPack key={`hp-${i}`} index={i} position={pos} />
      ))}
      <Player />
      <HunterManager />
    </>
  );
}
