/**
 * hunterState.js — Shared mutable singleton for Hunter detection results.
 *
 * Each Hunter writes its detection boolean to `detections[id]` every frame.
 * The damage system (Prompt 5) can call `isPlayerDetected()` to check if
 * ANY hunter currently has the player inside its spotlight cone.
 *
 * Same pattern as playerState.js — plain mutable object, zero re-renders.
 */

const hunterState = {
  /** Map of hunterId → boolean (is that hunter currently illuminating the player?) */
  detections: {},

  /** Map of hunterId → boolean (is that hunter currently physically touching the player?) */
  contacts: {},

  /** Convenience: returns true if ANY hunter currently sees the player */
  isPlayerDetected() {
    for (const id in this.detections) {
      if (this.detections[id]) return true;
    }
    return false;
  },

  /** Convenience: returns true if ANY hunter is touching the player */
  isPlayerInContact() {
    for (const id in this.contacts) {
      if (this.contacts[id]) return true;
    }
    return false;
  },
};

export default hunterState;
