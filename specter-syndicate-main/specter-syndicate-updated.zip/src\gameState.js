/**
 * gameState.js — Reactive bridge between the R3F game loop and the React DOM HUD.
 *
 * The game loop (Player.jsx useFrame) writes to this singleton at a throttled
 * rate. The HUD subscribes via gameState.subscribe() and re-renders only when
 * notified — keeping the hot path (useFrame) allocation-free while letting
 * React DOM update at a sane ~10-15fps cadence.
 */

const listeners = new Set();

const gameState = {
  health: 100,
  maxHealth: 100,
  healthPacks: [true, true, true, true],
  healPulse: 0,
  survivalTime: 0,
  detected: false,
  gameOver: false,
  victory: false,
  coreCollected: false,
  mode: 'purple',
  modeColor: '#a63bff',
  modeName: 'Stealth',
  syncedSurvivalTime: 0,
  hunterCount: 3,
  level: 1,
  levelComplete: false,

  /** Subscribe a callback; returns an unsubscribe function. */
  subscribe(fn) {
    listeners.add(fn);
    return () => listeners.delete(fn);
  },

  /** Notify all subscribers (called by Player.jsx on throttled updates). */
  notify() {
    listeners.forEach((fn) => fn());
  },

  /** Full reset — called on restart before Scene remounts. */
  reset(full = true) {
    this.health = 100;
    this.healthPacks = [true, true, true, true];
    this.healPulse = 0;
    this.survivalTime = 0;
    this.detected = false;
    this.gameOver = false;
    this.victory = false;
    this.coreCollected = false;
    this.levelComplete = false;
    if (full) {
      this.mode = 'purple';
      this.modeColor = '#a63bff';
      this.modeName = 'Stealth';
      this.level = 1;
    }
    this.syncedSurvivalTime = 0;
    this.hunterCount = 3;
    this.notify();
  },
};

export default gameState;
