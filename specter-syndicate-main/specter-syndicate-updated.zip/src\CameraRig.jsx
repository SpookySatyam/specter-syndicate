import React, { useRef, useLayoutEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { OrthographicCamera } from '@react-three/drei';
import * as THREE from 'three';
import playerState from './playerState';

const OFFSET = new THREE.Vector3(15, 15, 15);

export default function CameraRig() {
  const cameraRef = useRef();
  
  const initial = playerState.position;
  const lookAtTarget = useRef(new THREE.Vector3(initial.x, initial.y, initial.z));
  const desiredPos = useRef(new THREE.Vector3());
  const cameraStartPos = [initial.x + OFFSET.x, initial.y + OFFSET.y, initial.z + OFFSET.z];

  useLayoutEffect(() => {
    if (cameraRef.current) {
      cameraRef.current.position.set(...cameraStartPos);
      lookAtTarget.current.set(initial.x, initial.y, initial.z);
      cameraRef.current.lookAt(lookAtTarget.current);
    }
  }, []);

  useFrame((state, delta) => {
    if (!cameraRef.current) return;

    // Get current player position
    const { x, y, z } = playerState.position;
    
    // Lerp lookAt target towards player position
    desiredPos.current.set(x, y, z);
    lookAtTarget.current.lerp(desiredPos.current, delta * 4);
    
    // Lerp camera position towards player position + offset
    desiredPos.current.set(x + OFFSET.x, y + OFFSET.y, z + OFFSET.z);
    cameraRef.current.position.lerp(desiredPos.current, delta * 4);
    
    // Update camera rotation to point at the interpolated target
    cameraRef.current.lookAt(lookAtTarget.current);
  });

  return (
    <OrthographicCamera
      ref={cameraRef}
      makeDefault
      position={cameraStartPos}
      zoom={22}
      left={-38}
      right={38}
      top={38}
      bottom={-38}
      near={0.1}
      far={200}
    />
  );
}
